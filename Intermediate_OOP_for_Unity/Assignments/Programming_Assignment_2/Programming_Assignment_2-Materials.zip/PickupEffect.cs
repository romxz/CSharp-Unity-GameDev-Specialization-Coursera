﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// An enumeration of the pickup effects
/// </summary>
public enum PickupEffect
{
    Freezer,
    Speedup
}
